# chmod 777
# sudo python3 installer.py
import os, time, sys

os.system('clear')
os.system('apt install screen python3 python3-pip')
time.sleep(1)
os.system('python3 -m pip -r requirements.txt')
time.sleep(1)
os.system('clear')
time.sleep(5)
print('''
# "/data/*.json ( all json file must ur configurated )" - Must configurated
# And then open /routes/decorators.py, so you can change the disord wehbook discord for log (optional)
# if you can't use webhook logs you can deleted attack_routes.py code in line 14
# so finally type "screen python3 main.py"
''')
time.sleep(5)
sys.exit()